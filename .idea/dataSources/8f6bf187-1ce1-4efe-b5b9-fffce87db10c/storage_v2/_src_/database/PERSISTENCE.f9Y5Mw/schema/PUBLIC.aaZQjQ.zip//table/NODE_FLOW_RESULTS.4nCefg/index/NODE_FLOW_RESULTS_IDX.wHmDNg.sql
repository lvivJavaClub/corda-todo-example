create unique index NODE_FLOW_RESULTS_IDX
    on NODE_FLOW_RESULTS (FLOW_ID);


create index ATT_ID_IDX
    on NODE_ATTACHMENTS (ATT_ID);


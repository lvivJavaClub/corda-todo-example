create index EXT_ID_IDX
    on PK_HASH_TO_EXT_ID_MAP (EXTERNAL_ID);


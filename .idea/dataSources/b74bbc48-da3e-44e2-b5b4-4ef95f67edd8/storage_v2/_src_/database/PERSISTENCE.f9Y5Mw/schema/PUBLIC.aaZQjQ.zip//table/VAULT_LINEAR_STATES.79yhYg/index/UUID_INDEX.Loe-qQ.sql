create index UUID_INDEX
    on VAULT_LINEAR_STATES (UUID);

